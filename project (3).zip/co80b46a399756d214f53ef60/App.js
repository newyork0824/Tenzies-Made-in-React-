import React from 'react'
import Die from './Die'
import {nanoid} from "nanoid"
import Confetti from 'react-confetti'



export default function App(){
    const [dice,setDice] = React.useState(allNewDice())
    const [tenzies,setTenzies] = React.useState(false)
    const [numofRolls, setNumOfRolls] = React.useState(0)
    const[time, setTime] = React.useState(0)
    const [isActive, setIsActive] = React.useState(true)
    
   
   
    React.useEffect(() => {
        let interval = null 
       !tenzies ?  interval = setInterval(() => {
          
        setTime(prevTime => prevTime + 10)
        
    },10) 
    :
      clearInterval(interval)
      
      
      return() =>   clearInterval(interval) 
     
       
       
    },[tenzies])
    
    
    
    React.useEffect(() => {
        setTenzies(false)
        const allHeld = dice.every(die => die.isHeld)
        const firstValue = dice[0].value
        const allSameValue = dice.every(die => die.value === firstValue)
         if(allHeld && allSameValue) {
             setTenzies(true)
             console.log("You Won")
         }   
    },dice)
    
    

    
     function generateNewDie() {
      return{    
       value:Math.floor(Math.random() * 6) + 1,
       isHeld:false,
       id:nanoid()
       }
     }     
    
   
    
    function rollDice() {
         tenzies ? 
          setTime(0):
          ""
        
        tenzies ?
         
        setDice(allNewDice()) 
     :
    setNumOfRolls(prevRolls => prevRolls + 1)
      setDice(prevDice => prevDice.map(die => {
         return die.isHeld ?
         die :
         generateNewDie()
         
         
      
           
        
            
    }))
    tenzies ? 
    setNumOfRolls(0):
    ""
    
   tenzies ? 
   setIsActive(false) :
   ""
    
    
    
}
    
   
                               
    
    function allNewDice(){
        const newArray = []
        for(let i =0; i < 10; i++){
         newArray.push(generateNewDie())
        }
           return newArray    
    }
    

    
    
    function holdDice(id) {
       
       setDice(prevDice => prevDice.map(die => {
           return die.id === id ?
                {...die, isHeld: !die.isHeld} :
                die
        }))
    }
    
        
    const diceElements = dice.map(die => (
        <Die
         key={die.id}
          id={die.id}
           isHeld={die.isHeld}{...die} 
          holdDice={() => holdDice(die.id)}  />
    ))
        
    
    
    return (
    <main>
    <div className="info">
     <h1 className="title"> Tenzies </h1>
    <p className="game-info"> {tenzies ? "You Have Won!!" : "Roll until all dice are the same. Click each die to freeze it at its current value between rolls" }  </p>
    </div>
    
     
    <div className="die-container">
    {tenzies ? <Confetti /> : "" }
     {diceElements}    
     </div>
     <h3> Number of Rolls: {numofRolls} </h3>
    <h3> Time:<span> {(("0" + Math.floor(time / 60000) % 60)).slice(-2)} </span>
    <span> {(("0" + Math.floor(time/1000) % 60)).slice(-2)} </span>
    <span> {(("0" + Math.floor(time/10) % 100)).slice(-2)} </span> ,</h3>
     <button onClick={rollDice} className="roll-new-game-btn">{tenzies ? "New Game" : "Roll"} </button>

    </main>
     
        
    )
}

//function rollDice() {
    //    tenzies ?
       
      //  setDice(allNewDice()) 
   //  :
   // setNumOfRolls(prevRolls => prevRolls + 1)
   //   setDice(prevDice => prevDice.map(die => {
    //     return die.isHeld ?
    //     die :
         //generateNewDie()
    //  
           
        
            
  /////  }))
